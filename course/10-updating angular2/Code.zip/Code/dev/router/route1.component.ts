import { Component } from "@angular/core";
 
@Component({
    selector: 'my-route1',
    template: `
        <p>This is route 1. No subrouting, no parameters</p>
    `
})
export class Route1Component {
    
}