import { Component } from "@angular/core";

@Component({
    selector: 'my-subroute2',
    template: 'Subroute 2'
})
export class Subroute2Component {
    
}