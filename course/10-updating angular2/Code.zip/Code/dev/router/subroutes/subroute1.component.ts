import { Component } from "@angular/core";

@Component({
    selector: 'my-subroute1',
    template: 'Subroute 1'
})
export class Subroute1Component {
    
}