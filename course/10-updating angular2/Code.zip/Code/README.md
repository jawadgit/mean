# Angular 2 Beta / RC Comparison

A little Angular 2 showing the biggest code-related changes from Beta to RC status.

* Packaging / Imports (@angular instead of angular2)
* ngFor (let instead of #)
* New Router